### Configuration File (js/config.js)
```javascript
const CONFIG = {
    apiRTC: {
        apiKey: '',
        cloudUrl: 'https://cloud.apirtc.com'
    },
    Ably: {
        apiKey: ''
    }
}
